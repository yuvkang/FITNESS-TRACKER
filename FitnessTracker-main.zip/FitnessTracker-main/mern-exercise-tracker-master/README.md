# MERN Exercise Tracker
This project is created using MERN stack ([**MongoDB**](https://www.mongodb.com/), [**Express.js**](https://expressjs.com/), [**React.js**](https://reactjs.org/) and [**Node.js**](https://nodejs.org/)) with the help of a tutorial created by [**#FreeCodeCamp**](https://www.freecodecamp.org/).

Tutorial link (YouTube): [Learn the MERN Stack - Full Tutorial (MongoDB, Express, React, Node.js)](https://www.youtube.com/watch?v=7CqJlxBYj-M)